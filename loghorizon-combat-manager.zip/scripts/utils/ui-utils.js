export function addStyleAndHtml(style, html) {
  document.body.insertAdjacentHTML("beforeend", style + html);
}

export function makeDraggable(panel, dragHandle) {
  let isDragging = false;
  let startX, startY, initialLeft, initialTop;

  dragHandle.addEventListener("mousedown", (e) => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    initialLeft = parseInt(window.getComputedStyle(panel).left, 10);
    initialTop = parseInt(window.getComputedStyle(panel).top, 10);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  });

  function onMouseMove(e) {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    panel.style.left = `${initialLeft + dx}px`;
    panel.style.top = `${initialTop + dy}px`;
  }

  function onMouseUp() {
    isDragging = false;
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);
  }
}
