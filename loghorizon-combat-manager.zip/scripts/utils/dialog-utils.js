export async function showChoiceDialog(title, content) {
  return new Promise((resolve) => {
    new Dialog({
      title: title,
      content: content,
      buttons: {
        ok: {
          label: "확인",
          callback: (html) => {
            const selected = html.find('[name="choice"]:checked').val();
            resolve(selected);
          },
        },
        cancel: {
          label: "취소",
          callback: () => resolve(null),
        },
      },
      default: "ok",
    }).render(true);
  });
}
