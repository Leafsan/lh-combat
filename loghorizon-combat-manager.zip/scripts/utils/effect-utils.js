export async function applyWeaknessEffect(
  actor,
  existingEffects,
  weaknessValue,
  choice
) {
  if (choice === "overwrite") {
    await actor.deleteEmbeddedDocuments(
      "ActiveEffect",
      existingEffects.map((effect) => effect.id)
    );
  } else if (choice === "add") {
    for (let effect of existingEffects) {
      let currentValue = effect.flags.weaknessValue || 0;
      effect.flags.weaknessValue = currentValue + weaknessValue;
      await actor.updateEmbeddedDocuments("ActiveEffect", [effect]);
    }
    ui.notifications.info(
      `${actor.name}의 쇠약 상태에 ${weaknessValue}가 가산되었습니다.`
    );
  }
}

export async function createEffect(actor, label, icon, flags, count = 1) {
  for (let i = 0; i < count; i++) {
    await actor.createEmbeddedDocuments("ActiveEffect", [
      {
        label: label,
        icon: icon,
        changes: [],
        duration: { rounds: 10 },
        origin: actor.uuid,
        flags: flags,
      },
    ]);
  }
}
