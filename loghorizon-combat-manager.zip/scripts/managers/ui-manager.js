import {
  addWeaknessEffect,
  addAdditionalHitEffect,
} from "./effects-manager.js";
import { addStyleAndHtml, makeDraggable } from "../utils/ui-utils.js";
import { showChoiceDialog } from "../utils/dialog-utils.js";

const STYLE = `
  <style>
    #custom-button-panel {
      position: fixed;
      bottom: 20px;
      left: 20px;
      z-index: 1000;
      background-color: rgba(0, 0, 0, 0.8);
      border-radius: 5px;
      padding: 5px;
      display: flex;
      align-items: center;
      color: #fff;
      height: 50px;
      box-sizing: border-box;
    }
    #drag-handle {
      width: 30px;
      height: 100%;
      background-color: #333;
      border-radius: 3px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: move;
      margin-right: 5px;
    }
    #custom-button-panel button {
      margin-right: 5px;
      padding: 5px 10px;
      background-color: #007bff;
      border: none;
      border-radius: 3px;
      color: #fff;
      font-size: 14px;
      cursor: pointer;
      height: 100%;
    }
    #custom-button-panel button:hover {
      background-color: #0056b3;
    }
  </style>
`;

const HTML = `
  <div id="custom-button-panel">
    <div id="drag-handle">&#9776;</div>
    <button id="add-weakness">쇠약</button>
    <button id="add-additional-hit">추가타</button>
  </div>
`;

export function createCustomButtonPanel() {
  if (!game.user.isGM) return;

  addStyleAndHtml(STYLE, HTML);

  const panel = document.getElementById("custom-button-panel");
  const dragHandle = document.getElementById("drag-handle");
  makeDraggable(panel, dragHandle);

  document
    .getElementById("add-weakness")
    .addEventListener("click", async () => {
      await handleButtonClick(
        "쇠약 수치 설정",
        "weakness-value",
        addWeaknessEffect
      );
    });

  document
    .getElementById("add-additional-hit")
    .addEventListener("click", async () => {
      await handleButtonClick(
        "추가타 수치 및 개수 설정",
        ["additional-hits-value", "additional-hits-count"],
        addAdditionalHitEffect
      );
    });
}

async function handleButtonClick(title, inputNames, effectFunction) {
  const selectedTokens = canvas.tokens.controlled;
  if (selectedTokens.length === 0) {
    ui.notifications.warn("먼저 토큰을 선택하세요.");
    return;
  }

  const content = Array.isArray(inputNames)
    ? inputNames
        .map(
          (name) =>
            `<div class="form-group"><label>${name.replace(
              /-/g,
              " "
            )}:</label><input type="number" id="${name}" name="${name}" value="1" /></div>`
        )
        .join("")
    : `<div class="form-group"><label>${inputNames.replace(
        /-/g,
        " "
      )}:</label><input type="number" id="${inputNames}" name="${inputNames}" value="1" /></div>`;

  const values = await showChoiceDialog(title, `<form>${content}</form>`);

  if (values === null) {
    ui.notifications.info("작업이 취소되었습니다.");
    return;
  }

  for (let token of selectedTokens) {
    await effectFunction(token.actor, ...Object.values(values));
  }

  ui.notifications.info(
    `${selectedTokens.length}개의 토큰에 상태가 적용되었습니다.`
  );
}
