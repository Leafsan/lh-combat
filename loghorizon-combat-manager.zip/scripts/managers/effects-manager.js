import { showChoiceDialog } from "../utils/dialog-utils.js";
import { applyWeaknessEffect, createEffect } from "../utils/effect-utils.js";

export async function addWeaknessEffect(actor, weaknessValue) {
  const existingEffects = actor.effects.filter(
    (effect) => effect.label === "쇠약"
  );

  if (existingEffects.length > 0) {
    const choice = await showChoiceDialog(
      "쇠약 상태 처리",
      `
        <p>대상에게 이미 쇠약 상태가 있습니다. 기존 상태를 덮어쓸까요, 아니면 수치를 가산할까요?</p>
        <form>
          <div class="form-group">
            <label>
              <input type="radio" name="choice" value="overwrite" checked />
              덮어쓰기
            </label>
          </div>
          <div class="form-group">
            <label>
              <input type="radio" name="choice" value="add" />
              가산
            </label>
          </div>
        </form>
      `
    );

    if (choice === null) {
      ui.notifications.info("작업이 취소되었습니다.");
      return;
    }

    await applyWeaknessEffect(actor, existingEffects, weaknessValue, choice);
    if (choice === "add") return;
  }

  await createEffect(actor, "쇠약", "icons/svg/skull.svg", {
    weaknessValue: weaknessValue,
  });
  ui.notifications.info(
    `${actor.name}에게 쇠약(${weaknessValue}) 상태가 적용되었습니다.`
  );
}

export async function addAdditionalHitEffect(
  actor,
  additionalHitsValue,
  count
) {
  await createEffect(
    actor,
    "추가타",
    "icons/svg/swords.svg",
    { additionalHitsValue: additionalHitsValue },
    count
  );
  ui.notifications.info(
    `${actor.name}에게 ${count}개의 추가타(${additionalHitsValue}) 상태가 적용되었습니다.`
  );
}
